import sys

from pontomais.application import Application


def main():
    Application().run()


if __name__ == "__main__":
    sys.exit(main())
