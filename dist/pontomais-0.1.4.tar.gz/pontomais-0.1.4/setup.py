# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pontomais', 'pontomais.api', 'pontomais.commands', 'pontomais.config']

package_data = \
{'': ['*']}

install_requires = \
['cleo>=0.8.1,<0.9.0', 'pyfiglet>=0.8.post1,<0.9', 'requests>=2.25.1,<3.0.0']

entry_points = \
{'console_scripts': ['pontomais = pontomais.__main__:main']}

setup_kwargs = {
    'name': 'pontomais',
    'version': '0.1.4',
    'description': '',
    'long_description': None,
    'author': 'Adilson Pavan',
    'author_email': 'adilson.pavan@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
